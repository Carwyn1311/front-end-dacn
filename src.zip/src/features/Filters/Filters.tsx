import React from 'react';

export const Filters = (): JSX.Element => {
  return <div>Filters</div>;
};
