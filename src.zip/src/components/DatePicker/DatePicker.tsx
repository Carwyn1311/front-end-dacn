import React from 'react';

export const DatePicker = (): JSX.Element => {
  return <div>DatePicker</div>;
};
